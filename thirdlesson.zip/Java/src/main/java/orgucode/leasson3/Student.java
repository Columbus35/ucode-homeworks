package orgucode.leasson3;

public class Student {



}
